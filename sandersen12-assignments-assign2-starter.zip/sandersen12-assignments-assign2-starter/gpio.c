#include "gpio.h"

void gpio_init(void) {
}

void gpio_set_function(unsigned int pin, unsigned int function) {
   // TODO: Your code goes here.
}

unsigned int gpio_get_function(unsigned int pin) {
    return 0;  // TODO: Your code goes here.
}

void gpio_set_input(unsigned int pin) {
    // TODO: Your code goes here.
}

void gpio_set_output(unsigned int pin) {
    // TODO: your code goes here.
}

void gpio_write(unsigned int pin, unsigned int value) {
    // TODO: Your code goes here.
}

unsigned int gpio_read(unsigned int pin) {
    return 0;  // TODO: Your code goes here.
}
