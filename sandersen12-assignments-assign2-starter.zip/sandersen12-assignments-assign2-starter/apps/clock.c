#include "../gpio.h"
#include "../timer.h"

void main(void)
{
    // initialize and run your clock here
}
